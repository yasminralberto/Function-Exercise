
import Cocoa

func equation (answer : Int) {
    print("2 times 2 is \(answer)")
    
}
equation(answer: 2*2)

func printequation(answer: Int, Equation: String){
    print("\(Equation) is \(answer)")
}

printequation(answer: (4*4) , Equation: "4 times 4")
